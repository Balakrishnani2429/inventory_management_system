<?php
// CONTROLLER: Stock.php
class Stock extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model(['Product_model', 'Stock_model']);
    }

    public function form() {
        if ($_POST) {
            $this->Stock_model->insert($this->input->post());
            redirect('stock/report');
        }
        $data['products'] = $this->Product_model->get_all();
        $this->load->view('templates/header');
        $this->load->view('stock/form', $data);
        $this->load->view('templates/footer');
    }

    public function report() {
        $data['report'] = $this->Stock_model->get_stock_report();
        $this->load->view('templates/header');
        $this->load->view('stock/report', $data);
        $this->load->view('templates/footer');
    }
}