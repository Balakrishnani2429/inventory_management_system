<div class="container mt-4">
    <h2>Product List</h2>
    <a href="<?= base_url('products/add_edit_product') ?>" class="btn btn-primary mb-2">Add Product</a>
    <table class="table table-bordered">
        <thead>
            <tr><th>ID</th><th>Name</th><th>SKU</th><th>Price</th><th>Actions</th></tr>
        </thead>
        <tbody>
            <?php foreach ($products as $p): ?>
            <tr>
                <td><?= $p->id ?></td>
                <td><?= $p->name ?></td>
                <td><?= $p->sku ?></td>
                <td><?= $p->price ?></td>
                <td>
                    <a href="<?= base_url('products/add_edit_product/' . $p->id) ?>" class="btn btn-sm btn-warning">Edit</a>
                    <a href="<?= base_url('products/delete/' . $p->id) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this product?')">Delete</a>
                    <a href="<?= base_url('products/view_chart/' . $p->id) ?>" class="btn btn-sm btn-success">View Chart</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>